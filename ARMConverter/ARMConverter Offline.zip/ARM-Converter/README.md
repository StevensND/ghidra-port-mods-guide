# ARM-Converter by Mika Cybertron
This a Offline Tool Assembler and Disassembler Only for ARM64, ARM and THUMB!


# Support
- ARM to HEX Converter
- HEX to ARM Converter



[![Preview ARM Converter](https://i.imgur.com/9GDXep3.jpg)](https://www.youtube.com/watch?v=HKKKpK8NQ-s)

![](https://i.imgur.com/HmefXFm.png)


# Credits
- [Mika Cybertron](https://platinmods.com/members/mika-cybertron.43/) to creator of this tools
- [Keystone-engine.org](https://keystone-engine.org) for Assembler Converter/ARM to HEX Converter
- [Capstone-engine.org](https://capstone-engine.org) for Disassembler Converter/HEX to ARM Converter


# Contact
* Discord: Mika Cybertron#5240
* [Mika Cybertron - Platinmods.com](https://platinmods.com/members/mika-cybertron.43/)


https://platinmods.com/
