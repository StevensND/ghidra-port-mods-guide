import time

def convert_gdb_to_ghidra(gdb_address, gdb_info):
    gdb_address = int(gdb_address, 16)

    # Extract relevant information from GDB info
    gdb_base_main_nss = int(gdb_info["Main.nss"].split(" ")[0], 16)

    # Calculate the Ghidra address by subtracting the Main.nss base and adding 7100000000
    converted_address_ghidra = gdb_address - gdb_base_main_nss + 0x7100000000

    # Format the result to show only the value after 0x
    result_hex = format(converted_address_ghidra, 'x')

    return result_hex

file_path = "Ghidra_Offset.txt"

while True:
    gdb_address_input = input("Enter GDB address: ")

    if gdb_address_input.lower() == 'exit':
        break

    # Mocked GDB information (replace this with actual GDB info) can be 0x0080004CD0 also
    gdb_info = {
        "Main.nss": "0x0080005000"
    }

    converted_address_ghidra = convert_gdb_to_ghidra(gdb_address_input, gdb_info)

    print(f"Ghidra Address: {converted_address_ghidra}")

    # Save the result to the file
    with open(file_path, "a") as file:
        file.write(f"GDB Address: {gdb_address_input}, Ghidra Address: {converted_address_ghidra}\n")

# No need for a delay if the script is terminated by the user
