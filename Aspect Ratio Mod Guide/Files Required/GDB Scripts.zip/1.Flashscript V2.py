import re

def extract_addresses(input_text):
    addresses = re.findall(r'0x[0-9a-fA-F]+\s*-\s*0x[0-9a-fA-F]+', input_text)
    return list(set(addresses))

def execute_first_script():
    print("Type or Paste the MONITOR GET INFO text or the ADDRESS RANGE that you want to search for and press Enter (0x0000000000 - 0xffffffffff scan everything):")

    input_lines = []
    while True:
        line = input()
        if not line.strip():
            break
        input_lines.append(line)

    input_text = '\n'.join(input_lines)

    if input_text.strip().lower() != 'exit':
        extracted_addresses = extract_addresses(input_text)

        if extracted_addresses:
            print("Address range:")
            print(', '.join(extracted_addresses))
        else:
            print("No addresses found.")

if __name__ == "__main__":
    execute_first_script()

    input("Press Enter to execute the second script...")

    import re

    def extract_addresses(input_file, output_file, user_input_ranges, user_input):
        pattern = re.compile(r'0x[0-9a-fA-F]+ - 0x[0-9a-fA-F]+')

        with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
            outfile.write("\n")

            unique_addresses = set()
            for line in infile:
                matches = re.findall(pattern, line)
                for match in matches:
                    address_start, address_end = map(lambda x: int(x, 16), match.split(" - "))
                    for start, end in user_input_ranges:
                        if start <= address_start <= end and start <= address_end <= end:
                            unique_addresses.add((address_start, address_end, user_input))

            for address_start, address_end, user_input in unique_addresses:
                outfile.write(f"find {hex(address_start)}, {hex(address_end)}, {user_input}\n")

    input_filename = "gdb.txt"
    output_filename = "mappings.txt"

    user_input_ranges = input("Enter the address ranges separated by commas (e.g., 0x0080004000 - 0x0081c45fff, 0x2103c00000 - 0x2303bfffff): ")
    user_input_ranges = [tuple(map(lambda x: int(x, 16), r.strip().split(" - "))) for r in user_input_ranges.split(",")]
    user_input = input("Enter the Hexadecimal Representation value that Floating Point Converter gave you and Press Enter (e.g. 0x4091c71c): ")

    extract_addresses(input_filename, output_filename, user_input_ranges, user_input)
    
    with open(output_filename, 'r') as output_file:
        print(output_file.read())

    input(f"Addresses extracted from {input_filename} within the specified range and saved to {output_filename}. Press Enter to exit...")