import os

def find_addresses(file_path, ending_value=""):
    matching_addresses = []

    try:
        with open(file_path, 'r') as file:
            for line in file:
                # Assuming each line contains an address
                address = line.strip()

                # Check if the address ends with the specified value
                if address.endswith(ending_value):
                    matching_addresses.append(address)
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return matching_addresses

    return matching_addresses

def generate_watch_script(addresses):
    script_lines = []
    for address in addresses:
        script_lines.append(f"set *{address} = 0x4091c71c <<change it and check if it changes on CE>>")
        script_lines.append(f"awatch *{address} <<set the watchpoint>>")

    return script_lines

if __name__ == "__main__":
    while True:
        default_file_path = 'gdb.txt'

        # Check if gdb.txt exists in the current working directory
        if os.path.isfile(default_file_path):
            file_path = default_file_path
        else:
            file_path = input(f"Enter the file path (or press Enter to use '{default_file_path}'): ").strip()
            if not file_path:
                file_path = default_file_path

        ending_value = input("Type or Paste the final value (e.g. 0x829b9108) that GDB found (press Enter for all addresses, type 'exit' to quit): ").strip()

        if ending_value.lower() == 'exit':
            break

        result = find_addresses(file_path, ending_value)

        if result:
            print(f"Addresses ending with '{ending_value}':")
            for address in result:
                print(address)

            watch_script_lines = generate_watch_script(result)

            # Write the script lines to a new file (watch_script.txt)
            script_file_path = 'watch_script.txt'
            with open(script_file_path, 'w') as script_file:
                script_file.write('\n'.join(watch_script_lines))

            print(f"\nWatch script generated successfully. Check '{script_file_path}' for the watch commands.")

            # Display the content of the generated file in the console
            with open(script_file_path, 'r') as generated_file:
                print(f"\nContents of '{script_file_path}':")
                for line in generated_file:
                    print(line.strip())
        else:
            print(f"No addresses found ending with '{ending_value}'.")
